package controller;

public class BancoDeDados {

}
