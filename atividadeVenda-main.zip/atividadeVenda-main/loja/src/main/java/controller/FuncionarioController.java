package controller;

public class FuncionarioController {

}
