package repositories;

public class ClienteRepository {

}
