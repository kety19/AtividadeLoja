package repositories;

public class FuncionarioRepository {

}
