package repositories;

public class ProdutosRepository {

}
