package services;

public class VendaService {

}
