package entities;

public class FuncionarioEntity {

}
