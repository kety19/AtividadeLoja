package entities;

public class VendaEntity {

}
