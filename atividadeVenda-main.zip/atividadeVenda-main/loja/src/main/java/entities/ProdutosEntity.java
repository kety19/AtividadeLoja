package entities;

public class ProdutosEntity {

}
