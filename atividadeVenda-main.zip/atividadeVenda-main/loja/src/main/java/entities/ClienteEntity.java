package entities;

public class ClienteEntity {

}
