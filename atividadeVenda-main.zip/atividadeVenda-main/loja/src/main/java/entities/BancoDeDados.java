package entities;

public class BancoDeDados {

}
